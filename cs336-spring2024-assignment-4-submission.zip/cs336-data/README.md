# CS336 Spring 2024 Assignment 4: Data

Please write your code for assignment 4 in this directory.

To run unit tests (assuming you've followed the setup instructions in [the
parent directory's README.md](../README.md)):

``` sh
pytest -v
```
